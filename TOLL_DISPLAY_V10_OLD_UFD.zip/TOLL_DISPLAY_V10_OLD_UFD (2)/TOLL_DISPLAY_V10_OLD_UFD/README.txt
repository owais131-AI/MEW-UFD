TOLL DISPLAY V10 OLD UFD - pictures from the server, built-in defaults, live number plate
For the OLD HUB75 panels that work with the ESP32-HUB75-MatrixPanel-DMA library.
==========================================================

1. ARDUINO
   - Libraries: Adafruit GFX Library (+ Adafruit BusIO) and
     "ESP32 HUB75 LED MATRIX PANEL DMA Display" by mrcodetastic (Library Manager).
   - TOLL_DISPLAY folder: TOLL_DISPLAY.ino, UfdPanel.h, LedFont.h, PlateFont.h, UfdPng.h, BuiltinPics.h
     (FM6373_Panel.h is NOT used in this version)
   - If the panels are in the wrong order on /panel?test=1, use "Panel order" on /panel.
   - Board: ESP32 Dev Module, Partition Scheme "Default 4MB with spiffs". Upload.

2. SERVER (Tiny File Manager)  -  folder ufd_test
   - Upload the 7 files from server/ufd_test (replace the old ones):
       takeslip.png thankyou.png laneopen.png laneclosed.png            (64 x 64)
       payfare.png metag.png                                             (64 x 32, panel 1)
       idle1.png idle2.png                                                 (64 x 96)
   - New pictures: open them in UFD Image Studio, choose the name under
     "UFD server picture", press "Save for UFD server", upload the file.
     (Normal PNGs from other programs are compressed: the UFD refuses them,
      keeps the current picture and says why on /status.)
   - Idle: up to idle6.png. Delete an idle file on the server -> not shown anymore.

3. UFD
   - Works right away with the built-in pictures, even without the server.
   - Downloads changed pictures in the background (start, every 5 min, /refresh).
   - /status shows for every picture: server copy / built-in / not shown.

4. COMMANDS
   /takeslip                               take slip picture
   /?vehicle_number=BMY083&take_slip       take slip + vehicle number on panel 3
   /?vehicle_number=BMY083&fare_amount=150 pay toll + vehicle and RS 150 on panel 3
   /?vehicle_number=BMY083&metag_paid=100&balance=4200
                                           ME-TAG paid: logo, vehicle, PAID RS 100 / BAL RS 4200
   /?vehicle_number=BMY083&metag_low       ME-TAG low balance: logo, vehicle, LOW BALANCE / RECHARGE
   /thankyou   /open                        picture, back to idle after 10 s
   /closed                                  stays until the next command
   /display?line1=..&line2=..&color=..      plain text
   /idle  /refresh  /status  /config  /panel  /color?c=red

5. PANEL TUNING
   Default settings (tested on the old panels, 3 stacked):
     scan 1/8, 8 MHz, clock edge A, latch 2, refresh >= 60 Hz, 8 bit colour, shift register.
   A new ESP32 starts with these automatically.
   http://<ip>/config -> "HUB75 panel tuning": scan mode, clock speed, clock edge,
   latch blanking, minimum refresh, colour depth, driver chip.
   "Save & Restart" stores them and restarts the ESP32 (about 10 s).
   The current values are shown on /status and in the Serial Monitor at start.

6. NETWORK START (crash fix)
   Default network: static IP 192.168.78.30, gateway 192.168.78.1, subnet 255.255.254.0, DNS 8.8.8.8.
   If the W5500 does not answer at start, the ESP32 no longer crashes/restarts:
   the display keeps running and Ethernet is tried again every 10 seconds.
   Optional: wire the W5500 RST pin to GPIO 32 and set  #define W5500_RST 32
